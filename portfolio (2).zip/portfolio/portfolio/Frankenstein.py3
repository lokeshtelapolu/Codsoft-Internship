from collections import defaultdict

# Parse input
n = int(input().strip())
recipes = defaultdict(list)

for _ in range(n):
    left, right = input().strip().split("=")
    ingredients = right.split("+")
    recipes[left].append(ingredients)

target = input().strip()

# Memoization dictionary
memo = {}

def min_orbs(potion):
    if potion in memo:
        return memo[potion]
    if potion not in recipes:
        memo[potion] = 0
        return 0

    min_cost = float('inf')
    for ingredients in recipes[potion]:
        cost = len(ingredients) - 1
        valid = True
        for ing in ingredients:
            sub_cost = min_orbs(ing)
            if sub_cost == float('inf'):
                valid = False
                break
            cost += sub_cost
        if valid:
            min_cost = min(min_cost, cost)
    memo[potion] = min_cost
    return min_cost

ans = min_orbs(target)
print(ans if ans != float('inf') else -1, end="")
